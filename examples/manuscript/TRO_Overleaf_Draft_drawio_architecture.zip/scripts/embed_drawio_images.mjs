import { readFile, writeFile } from "node:fs/promises";
import { resolve } from "node:path";

const root = resolve(new URL("..", import.meta.url).pathname);
const diagramPath = resolve(root, "figures/architecture_drawio.drawio");

const images = [
  "carter_simulation_model.png",
  "go2_simulation_model.png",
];

let xml = await readFile(diagramPath, "utf8");

for (const name of images) {
  const absolutePath = resolve(root, name);
  const bytes = await readFile(absolutePath);
  // draw.io style strings use semicolons as delimiters; the image data URI
  // therefore follows draw.io's comma form instead of `;base64,`.
  const encoded = `data:image/png,${bytes.toString("base64")}`;
  const external = `file://${absolutePath}`;
  xml = xml.replace(external, encoded);
}

xml = xml.replaceAll("data:image/png;base64,", "data:image/png,");

await writeFile(diagramPath, xml, "utf8");
